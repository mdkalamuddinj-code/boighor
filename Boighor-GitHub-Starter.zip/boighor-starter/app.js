// Boighor starter. Add your Supabase project URL and anon key below.
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY";
const configured = SUPABASE_URL.startsWith("https://") && !SUPABASE_URL.includes("PASTE_") && !SUPABASE_ANON_KEY.includes("PASTE_");
const db = configured ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
const $ = (id) => document.getElementById(id);
const authDialog = $("authDialog"), privateDialog = $("privateDialog");
let currentUser = null;

function note(id, message){ $(id).textContent = message; }
function safeText(s){ return String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function setupNotice(){ if(!db) note("submitMsg","সাইট সেটআপ সম্পূর্ণ হয়নি। README-এর Supabase ধাপগুলো শেষ করুন।"); }
async function refreshUser(){
  if(!db) return;
  const {data:{session}} = await db.auth.getSession();
  currentUser = session?.user || null;
  $("authOpen").textContent = currentUser ? "আমার অ্যাকাউন্ট" : "লগইন";
}
async function loadPublic(){
  if(!db){ $("publicBooks").innerHTML='<div class="empty">Supabase যুক্ত করলে অনুমোদিত বই এখানে দেখা যাবে।</div>'; return; }
  const {data,error} = await db.from("books").select("id,title,author,category,description").eq("status","approved").eq("visibility","public").order("created_at",{ascending:false});
  if(error){ $("publicBooks").innerHTML='<div class="empty">বই লোড করা যায়নি।</div>'; return; }
  renderBooks("publicBooks",data || [],true);
}
function renderBooks(target, books, showRead){
  const el=$(target);
  if(!books.length){el.innerHTML='<div class="empty">এখনো কোনো বই যোগ করা হয়নি।</div>';return;}
  el.innerHTML=books.map(b=>`<article class="book-card"><div class="cover">বই</div><h3>${safeText(b.title)}</h3><small>${safeText(b.author)} · ${safeText(b.category)}</small><p class="muted">${safeText(b.description || "")}</p>${showRead?`<a href="#" data-read="${safeText(b.id)}">বই পড়ুন ↗</a>`:""}</article>`).join("");
  el.querySelectorAll("[data-read]").forEach(a=>a.addEventListener("click",async e=>{e.preventDefault();await readBook(a.dataset.read,false);}));
}
async function readBook(id,isPrivate){
  const {data,error}=await db.from("books").select("file_path,title").eq("id",id).single();
  if(error){alert("এই বইটি খোলা যাচ্ছে না।");return;}
  const bucket=isPrivate?"private-books":"public-books";
  const {data:link,error:linkError}=await db.storage.from(bucket).createSignedUrl(data.file_path,90);
  if(linkError){alert("বইয়ের ফাইল পাওয়া যায়নি।");return;}
  window.open(link.signedUrl,"_blank","noopener");
}
$("authOpen").addEventListener("click",()=>authDialog.showModal());
$("privateOpen").addEventListener("click",async()=>{
  if(!db){privateDialog.showModal();note("privateMsg","প্রথমে Supabase সেটআপ সম্পন্ন করুন।");return;}
  if(!currentUser){authDialog.showModal();note("authMsg","ব্যক্তিগত তাক দেখতে আগে অ্যাডমিন অ্যাকাউন্টে লগইন করুন।");return;}
  await loadPrivate();privateDialog.showModal();
});
$("authForm").addEventListener("submit",async e=>{
  e.preventDefault();if(!db){note("authMsg","Supabase সেটআপ এখনো হয়নি।");return;}
  const f=new FormData(e.currentTarget),email=f.get("email"),password=f.get("password");
  const {error}=await db.auth.signInWithPassword({email,password});
  if(error){note("authMsg",error.message);return;}
  await refreshUser();note("authMsg","লগইন সফল।");setTimeout(()=>authDialog.close(),500);
});
$("signup").addEventListener("click",async()=>{
  if(!db){note("authMsg","Supabase সেটআপ এখনো হয়নি।");return;}
  const f=new FormData($("authForm"));
  const {error}=await db.auth.signUp({email:f.get("email"),password:f.get("password")});
  note("authMsg",error?error.message:"অ্যাকাউন্ট তৈরি হয়েছে। ইমেইল নিশ্চিত করুন, তারপর লগইন করুন।");
});
$("submitForm").addEventListener("submit",async e=>{
  e.preventDefault();if(!db){note("submitMsg","Supabase সেটআপ সম্পূর্ণ করুন।");return;}
  if(!currentUser){authDialog.showModal();note("authMsg","বই জমা দিতে আগে লগইন করুন।");return;}
  const f=new FormData(e.currentTarget),file=f.get("file");
  if(!file || file.type!=="application/pdf"){note("submitMsg","শুধু PDF ফাইল জমা দেওয়া যাবে।");return;}
  const id=crypto.randomUUID(),path=`${currentUser.id}/${id}.pdf`;
  note("submitMsg","ফাইল আপলোড হচ্ছে...");
  const {error:upErr}=await db.storage.from("public-books").upload(path,file,{contentType:"application/pdf",upsert:false});
  if(upErr){note("submitMsg",upErr.message);return;}
  const {error}=await db.from("books").insert({id,title:f.get("title"),author:f.get("author"),category:f.get("category"),description:f.get("description"),file_path:path,visibility:"public",status:"pending",owner_id:currentUser.id});
  if(error){note("submitMsg","বইয়ের তথ্য জমা হয়নি: "+error.message);return;}
  e.currentTarget.reset();note("submitMsg","ধন্যবাদ! বইটি রিভিউয়ের জন্য জমা হয়েছে। অনুমোদনের পর প্রকাশ হবে।");
});
async function loadPrivate(){
  const {data,error}=await db.from("books").select("id,title,author,category,description").eq("status","approved").eq("visibility","private").order("created_at",{ascending:false});
  if(error){note("privateMsg","ব্যক্তিগত বই লোড করা যায়নি।");return;}
  renderBooks("privateBooks",data||[],false);
  $("privateBooks").querySelectorAll(".book-card").forEach((card,i)=>{const b=data[i];const a=document.createElement("a");a.href="#";a.textContent="বই পড়ুন ↗";a.onclick=e=>{e.preventDefault();readBook(b.id,true);};card.append(a);});
}
if(db){db.auth.onAuthStateChange(()=>refreshUser());}
$("search").addEventListener("input",filterBooks);$("category").addEventListener("change",filterBooks);
let cachedBooks=[];
async function filterBooks(){
  if(!db)return;
  const term=$("search").value.toLowerCase(),cat=$("category").value;
  const {data}=await db.from("books").select("id,title,author,category,description").eq("status","approved").eq("visibility","public").order("created_at",{ascending:false});
  const filtered=(data||[]).filter(b=>(!cat||b.category===cat)&&(!term||(b.title+" "+b.author).toLowerCase().includes(term)));
  renderBooks("publicBooks",filtered,true);
}
setupNotice();refreshUser();loadPublic();