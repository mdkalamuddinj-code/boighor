-- BOIGHOR database setup for Supabase
-- Run in Supabase SQL Editor. Then follow README to promote YOUR account to admin.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('member','admin')),
  created_at timestamptz not null default now()
);
create table if not exists public.books (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  author text not null,
  category text not null default 'অন্যান্য',
  description text,
  file_path text not null,
  visibility text not null default 'public' check (visibility in ('public','private')),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  owner_id uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.books enable row level security;

create or replace function public.make_profile()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,role) values(new.id,'member') on conflict(id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.make_profile();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='admin');
$$;

create policy "profiles read own or admin" on public.profiles for select to authenticated
using (id=auth.uid() or public.is_admin());
create policy "public approved books visible" on public.books for select
using (visibility='public' and status='approved');
create policy "members submit public pending books" on public.books for insert to authenticated
with check (owner_id=auth.uid() and visibility='public' and status='pending');
create policy "admins manage all books" on public.books for all to authenticated
using (public.is_admin()) with check (public.is_admin());

-- Storage buckets
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('public-books','public-books',false,20971520,array['application/pdf'])
on conflict(id) do nothing;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('private-books','private-books',false,20971520,array['application/pdf'])
on conflict(id) do nothing;

-- Submitted files: a member can upload into their own folder; only approved book records
-- are visible via signed URLs generated after the books-table policy check.
create policy "member uploads own public book pdf" on storage.objects for insert to authenticated
with check (bucket_id='public-books' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "approved public book files readable" on storage.objects for select
using (
  bucket_id='public-books' and exists (
    select 1 from public.books b
    where b.file_path=name and b.visibility='public' and b.status='approved'
  )
);
create policy "admin reads public book files" on storage.objects for select to authenticated
using (bucket_id='public-books' and public.is_admin());
create policy "admin manages public book files" on storage.objects for all to authenticated
using (bucket_id='public-books' and public.is_admin())
with check (bucket_id='public-books' and public.is_admin());

-- Private shelf: admin only, both metadata and file access.
create policy "admin reads private book files" on storage.objects for select to authenticated
using (bucket_id='private-books' and public.is_admin());
create policy "admin manages private book files" on storage.objects for all to authenticated
using (bucket_id='private-books' and public.is_admin())
with check (bucket_id='private-books' and public.is_admin());

-- IMPORTANT: after creating your account, find its UUID in Authentication > Users.
-- Run this separately, replacing YOUR-USER-UUID:
-- update public.profiles set role='admin' where id='YOUR-USER-UUID';
